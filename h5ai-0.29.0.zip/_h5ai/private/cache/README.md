# Cache

Private cache.

This directory is used for server side caching. To use caching make this
directory writable for your webserver.

There is no critical data in here. You can savely remove any content. This
will clear the cache.
